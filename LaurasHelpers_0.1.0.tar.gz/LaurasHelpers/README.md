# LaurasHelpers

This GitHub repository contains functions I've found useful in my work as a research scientist doing pharmacokinetic analyses and quantitative, analytical chemistry. 

- Laura Shireman, Ph.D.